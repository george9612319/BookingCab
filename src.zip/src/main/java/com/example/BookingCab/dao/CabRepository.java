package com.example.BookingCab.dao;

import org.springframework.data.repository.CrudRepository;

import com.example.BookingCab.model.Cab;

public interface CabRepository extends CrudRepository<Cab,Integer> {

}
